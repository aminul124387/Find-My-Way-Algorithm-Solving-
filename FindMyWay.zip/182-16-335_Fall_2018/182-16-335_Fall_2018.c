/*
Program  - A Queue of peoples waiting at star cineplex ticket counter,
Author   - MD AMINUL ISLAM
Language - C Language
Date     - 03/12/2018 (dd/mm/yyyy)
*/
#include<stdio.h>
#define MAX 50

typedef struct vertex_edge
{
    int u,v,w;
} vertex_edge;
/*
Declared structure to take multiple value in array
*/
typedef struct vertex_edgelist
{
    vertex_edge data[MAX];
    int containter;
} vertex_edgelist;

/*
Declared structure to take multiple edge-list from the graph
*/
vertex_edgelist elist; // make object for the structure express edge list


int G[MAX][MAX],containter; //Declared 2D array
vertex_edgelist sortedlist; //Make object for store sorted edge list

/*
Create Make-set for make disjoint subset
*/

void make_set();
int find(int parents[],int vertexno); // Compare the edges to find shortest edge
void union1(int parents[],int col1,int col2); // Take shortest edge weight after finding unique shortest weight
void sort(); // Call sorted function
void print(); // call print function

void main()  // Declare main function
{
    int i,j,total_cost; // declare the variable

    printf("\n===*===*===== Assignment Title: ====*=====*==");
    printf("\n===*===*===*== Find the Way ==*===*===*===");
    printf("\n=========== Fall 2018 ===========");
    printf("\n\n\nPlease Enter containterber of vertices or node:\t");

    scanf("%d",&containter); // take input vertex from the user

    printf("\nEnter the adjacency matrix. Enter 0 if not adjacent and weight if adjacent:\n");

    for(i=0; i<containter; i++) // loop declare for take multiple vertex and edges
    {
        for(j=0; j<containter; j++) //loop Declared for the take multiple graph weight
        {
            printf("Weight between %d,  %d: ",i,j);
            scanf("%d",&G[i][j]);
        }
    }


    make_set();
    print();
}

/*
    Disjoint Function work here, and also work its two function:
    Find function
    Union function
*/

void make_set()
{
    int parents[MAX],i,j,comp1,comp2;
    elist.containter=0;

    for(i=1; i<containter; i++)
        for(j=0; j<i; j++)
        {
            if(G[i][j]!=0) // finding the sorted weight from the user input
            {
                elist.data[elist.containter].u=i;
                elist.data[elist.containter].v=j;
                elist.data[elist.containter].w=G[i][j]; //  Union collect the final weight from the user input graph weight
                elist.containter++;
            }
        }

    sort();

    for(i=0; i<containter; i++)
        parents[i]=i;

    sortedlist.containter=0;

    for(i=0; i<elist.containter; i++)
    {
        comp1=find(parents,elist.data[i].u);
        comp2=find(parents,elist.data[i].v);

        if(comp1!=comp2)
        {
            sortedlist.data[sortedlist.containter]=elist.data[i];
            sortedlist.containter=sortedlist.containter+1;
            union1(parents,comp1,comp2);
        }
    }
}

int find(int parents[],int vertexno)
{
    return(parents[vertexno]);
}

void union1(int parents[],int col1,int col2)
{
    int i;

    for(i=0; i<containter; i++)
        if(parents[i]==col2)
            parents[i]=col1;
}

/*
 Using the bubble sort for the sorted weight
*/
void sort()
{
    int i,j;
    vertex_edge key;

    for(i=1; i<elist.containter; i++)
        for(j=0; j<elist.containter-1; j++)
            if(elist.data[j].w>elist.data[j+1].w)
            {
                key=elist.data[j];
                elist.data[j]=elist.data[j+1];
                elist.data[j+1]=key;
            }


}



void print() //print all task here:
{
    int i,cost=0;
    printf("\n\n===*==* Here show the shortest path of the Graph *==*====*\n");
    printf("Source\t Destination\t weight");
    for(i=0; i<sortedlist.containter; i++)
    {
        printf("\n\n%d\t\t%d\t%d",sortedlist.data[i].u,sortedlist.data[i].v,sortedlist.data[i].w);
        cost=cost+sortedlist.data[i].w;

    }

    printf("\nShortest Path: ");   // Show the  shortest path between the source and destination
    for(i = 0; i <= containter - 1; i++)
      {
            printf("%d>%d>", sortedlist.data[i].u,sortedlist.data[i].v);
      }


    printf("\n\n=*==*==The Minimum spanning tree ===*===*===");
    printf("\n\nTotal Cost = %d",cost);
}
